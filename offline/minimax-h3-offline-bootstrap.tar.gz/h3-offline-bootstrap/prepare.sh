#!/usr/bin/env bash
set -euo pipefail

bundle_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
cd -- "$bundle_dir"
sha256sum -c SHA256SUMS

: "${IFAB_AFS_HOME:?Open an InfiniFabric terminal with personal AFS storage.}"
if [[ $(uname -s) != Linux || $(uname -m) != x86_64 ]]; then
  printf 'The bundled xmake executable requires Linux x86_64.\n' >&2
  exit 1
fi

work_dir="$IFAB_AFS_HOME/minimax-h3-work"
mkdir -p -- "$work_dir"
stage_dir=$(mktemp -d "$work_dir/offline.XXXXXX")
printf 'Staging source and tools under %s\n' "$stage_dir"
mkdir -- "$stage_dir/bin" "$stage_dir/wheels"
tar -xzf InfiniCore-f32e2fbb-offline-source-20261029.tar.gz -C "$stage_dir"
tar -xzf InfiniLM-minimax_h3-full.tar.gz -C "$stage_dir"
tar -xzf infinilm-runtime-wheels-py311-x86_64.tar.gz -C "$stage_dir/wheels"
cp -- ./*.whl "$stage_dir/wheels/"
install -m 755 xmake-bundle-v3.0.5.linux.x86_64 "$stage_dir/bin/xmake"

core_dir="$stage_dir/InfiniCore"
lm_dir="$stage_dir/InfiniLM-minimax_h3-full"
test -f "$core_dir/third_party/spdlog/include/spdlog/spdlog.h"
test -f "$lm_dir/third_party/json/single_include/nlohmann/json.hpp"
test -f "$lm_dir/examples/minimax_h3.py"
test -f "$lm_dir/examples/minimax_h3_compare.py"

printf '\nCORE_DIR=%s\nINFINILM_REPO=%s\nXMAKE=%s\nWHEEL_DIR=%s\n' \
  "$core_dir" "$lm_dir" "$stage_dir/bin/xmake" "$stage_dir/wheels"
GIT_CONFIG_NOSYSTEM=1 git -C "$core_dir" log -1 --format='INFINICORE_COMMIT=%H'
printf '=== xmake ===\n'
"$stage_dir/bin/xmake" --version
printf '=== HIP compiler ===\n'
command -v hipcc || printf 'hipcc is not on PATH in this login shell.\n'
for candidate in /opt/dtk/bin/hipcc /opt/rocm/bin/hipcc /usr/local/rocm/bin/hipcc; do
  if [[ -x $candidate ]]; then
    printf 'hipcc candidate: %s\n' "$candidate"
  fi
done
printf 'Offline files prepared. Native compilation has not started.\n'
