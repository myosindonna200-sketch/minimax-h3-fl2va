# InfiniFabric 离线源码准备

GitHub 代理出现 502 时，将压缩包上传到 InfiniFabric 的「个人存储」根目录，在 CPU 登录工作区运行：

```bash
cd "${IFAB_AFS_HOME:?当前终端没有个人持久存储路径}" &&
  tar -xzf minimax-h3-offline-bootstrap.tar.gz &&
  bash h3-offline-bootstrap/prepare.sh
```

脚本校验载荷，将源码、xmake 和 Python 3.11 可用的部分 wheel 展开到个人存储的新目录，并检查 xmake 是否能启动、是否能找到 HIP 编译器。保留输出中的 `CORE_DIR`、`INFINILM_REPO`、`XMAKE` 和 `WHEEL_DIR`。下一步根据节点 SDK、GPU 架构和 Torch ABI 配置编译。本包没有改动平台的软件或启动项目，也没有开始八卡推理。

- InfiniCore 基线为 `f32e2fbb2a9b2ca912b5711f4f3836c403196a74` 的历史离线包。保留了 Git 元数据和 `spdlog`，其余可选子模块按实际编译选项准备。
- InfiniLM 为 2026 年 10 月 21 日保存的 `minimax_h3` 源码快照，含 `json` 与 `spdlog`。用 `SHA256SUMS` 记录快照版本。
- xmake 为此前核验过的官方 v3.0.5 Linux x86_64 bundle，来源为 https://github.com/xmake-io/xmake/releases/tag/v3.0.5 。Python wheels 来自此前留存的离线依赖包，未安装到目标机器。
- 模型权重走赛方共享目录，HIP SDK 和剩余构建、推理依赖按平台实测补齐。
